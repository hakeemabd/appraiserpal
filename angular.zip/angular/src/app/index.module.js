(function () {
    'use strict';

    angular
        .module('appraiserpal', [
            "appraiserpal.core",
            "appraiserpal.order",
            "appraiserpal.profile",
            "appraiserpal.fileManager"
        ]);

})();
