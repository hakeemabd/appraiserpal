(function () {
  'use strict';

  angular.module('appraiserpal.fileManager.cloneFileManager', []);

})();
