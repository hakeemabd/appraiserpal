(function () {
    'use strict';

    angular
        .module('appraiserpal.order', [
            'appraiserpal.order.createOrder',
            'appraiserpal.order.checkout'
        ]);

})();