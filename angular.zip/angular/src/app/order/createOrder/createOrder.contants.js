(function () {
  'use strict';

  angular.module('appraiserpal.order.createOrder').constant("ADJUSTMENT_TYPE", {
    'NONE': 'none',
    'REGRESSION': 'add regression',
    'OWN': 'own'
  })
})();
