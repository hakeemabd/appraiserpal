(function () {
  'use strict';

  angular.module('appraiserpal.order.createOrder').run(runBlock);

  runBlock.$inject = [];

  function runBlock() {
  }

})();
