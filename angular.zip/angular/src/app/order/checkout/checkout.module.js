(function () {
    'use strict';

    angular
        .module('appraiserpal.order.checkout', []);

})();